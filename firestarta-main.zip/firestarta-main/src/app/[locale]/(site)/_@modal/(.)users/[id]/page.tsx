import Modal from "./Modal";

export default function User() {
  return <Modal />;
}
