import { LemonSqueezy } from "@lemonsqueezy/lemonsqueezy.js";

const ls = new LemonSqueezy(process.env.LEMONSQUEEZY_API_KEY);

export default ls;
